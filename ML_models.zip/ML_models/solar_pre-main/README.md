solr presiction 
